import os
import sys
import json
import random

import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms, datasets
from tqdm import tqdm
from model import resnet50  # 导入ResNet50网络


def main():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("using {} device.".format(device))

    data_transform = {
        "train": transforms.Compose([transforms.RandomResizedCrop(224),
                                     transforms.RandomHorizontalFlip(),
                                     transforms.ToTensor(),
                                     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]),
        "val": transforms.Compose([transforms.Resize(256),
                                   transforms.CenterCrop(224),
                                   transforms.ToTensor(),
                                   transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}

    # 数据路径：指向 resnet/data/all_data 目录
    image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "all_data")
    assert os.path.exists(image_path), "{} path does not exist.".format(image_path)

    # 加载全部数据
    full_dataset = datasets.ImageFolder(root=image_path, transform=data_transform["train"])
    total_num = len(full_dataset)

    # 获取类别映射并保存为json
    class_list = full_dataset.class_to_idx
    cla_dict = dict((val, key) for key, val in class_list.items())
    json_str = json.dumps(cla_dict, indent=4)
    with open('class_indices.json', 'w') as json_file:
        json_file.write(json_str)

    # 按 8:2 划分训练集和验证集
    val_ratio = 0.2
    indices = list(range(total_num))
    random.seed(42)
    random.shuffle(indices)
    split = int(total_num * (1 - val_ratio))
    train_indices = indices[:split]
    val_indices = indices[split:]

    # 创建子集，验证集使用不同的transform
    train_dataset = torch.utils.data.Subset(full_dataset, train_indices)

    # 验证集需要单独的transform，重新加载
    val_dataset_full = datasets.ImageFolder(root=image_path, transform=data_transform["val"])
    val_dataset = torch.utils.data.Subset(val_dataset_full, val_indices)

    train_num = len(train_indices)
    val_num = len(val_indices)

    batch_size = 16
    nw = min([os.cpu_count(), batch_size if batch_size > 1 else 0, 8])
    print('Using {} dataloader workers every process'.format(nw))

    train_loader = torch.utils.data.DataLoader(train_dataset,
                                               batch_size=batch_size, shuffle=True,
                                               num_workers=nw)
    validate_loader = torch.utils.data.DataLoader(val_dataset,
                                                  batch_size=batch_size, shuffle=False,
                                                  num_workers=nw)

    print("using {} images for training, {} images for validation.".format(train_num, val_num))

    # 使用ResNet50进行迁移学习
    net = resnet50()
    # 加载预训练权重（自动下载）
    try:
        from torchvision.models import ResNet50_Weights
        from torchvision.models import resnet50 as torchvision_resnet50
        pretrained_model = torchvision_resnet50(weights=ResNet50_Weights.DEFAULT)
        net.load_state_dict(pretrained_model.state_dict(), strict=False)
        print("Loaded pretrained weights from torchvision.")
    except Exception:
        # 如果torchvision不可用，尝试从本地文件加载
        model_weight_path = "./resnet50-19c8e357.pth"
        if os.path.exists(model_weight_path):
            net.load_state_dict(torch.load(model_weight_path, map_location='cpu'), strict=False)
            print("Loaded pretrained weights from local file.")
        else:
            print("Warning: No pretrained weights loaded. Training from scratch.")

    # 替换最后的全连接层为7类分类
    in_channel = net.fc.in_features
    net.fc = nn.Linear(in_channel, 7)
    net.to(device)

    # 定义损失函数
    loss_function = nn.CrossEntropyLoss()

    # 构造优化器
    params = [p for p in net.parameters() if p.requires_grad]
    optimizer = optim.Adam(params, lr=0.0001)

    epochs = 30
    best_acc = 0.0
    save_path = './resnet50_mineral.pth'
    history = {'train_loss': [], 'val_acc': []}  # 记录每个epoch的训练损失和验证准确率
    train_steps = len(train_loader)
    for epoch in range(epochs):
        # 训练阶段
        net.train()
        running_loss = 0.0
        train_bar = tqdm(train_loader, file=sys.stdout)
        for step, data in enumerate(train_bar):
            images, labels = data
            optimizer.zero_grad()
            logits = net(images.to(device))
            loss = loss_function(logits, labels.to(device))
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            train_bar.desc = "train epoch[{}/{}] loss:{:.3f}".format(epoch + 1, epochs, loss)

        # 验证阶段
        net.eval()
        acc = 0.0
        with torch.no_grad():
            val_bar = tqdm(validate_loader, file=sys.stdout)
            for val_data in val_bar:
                val_images, val_labels = val_data
                outputs = net(val_images.to(device))
                predict_y = torch.max(outputs, dim=1)[1]
                acc += torch.eq(predict_y, val_labels.to(device)).sum().item()
                val_bar.desc = "valid epoch[{}/{}]".format(epoch + 1, epochs)

        val_accurate = acc / val_num
        epoch_loss = running_loss / train_steps
        history['train_loss'].append(epoch_loss)
        history['val_acc'].append(val_accurate)
        print('[epoch %d] train_loss: %.3f  val_accuracy: %.3f' %
              (epoch + 1, epoch_loss, val_accurate))

        if val_accurate > best_acc:
            best_acc = val_accurate
            torch.save(net.state_dict(), save_path)

    print('Finished Training')
    print('Best validation accuracy: %.3f' % best_acc)

    # 保存训练历史，供后续报告绘图使用
    with open('train_history.json', 'w') as f:
        json.dump(history, f, indent=4)
    print('Training history saved to train_history.json')


if __name__ == '__main__':
    main()